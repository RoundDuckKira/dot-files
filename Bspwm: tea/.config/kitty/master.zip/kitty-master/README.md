# Dracula for [kitty](https://sw.kovidgoyal.net/kitty/)

> A dark theme for [kitty](https://sw.kovidgoyal.net/kitty/).

![Screenshot](./screenshot.png)

## Install

All instructions can be found at [draculatheme.com/kitty](https://draculatheme.com/kitty).

## Team

<!-- This theme is maintained by the following person and a bunch of [awesome contributors](https://github.com/dracula/kitty/graphs/contributors). -->

| [![Keegan Carruthers-Smith](https://avatars0.githubusercontent.com/u/187831?v=3&s=70)](https://github.com/keegancsmith) | [![Daniel Mita](https://avatars0.githubusercontent.com/u/966706?v=3&s=70)](https://github.com/mienaikage) |
| ----------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------- |
| [Keegan Carruthers-Smith](https://github.com/keegancsmith)                                                              | [Daniel Mita](https://github.com/mienaikage)                                                              |

## License

[MIT License](./LICENSE)
